"""Explicit, budgeted Voyage calls and immutable offline solver embedding bundles."""

import argparse
import datetime
import json
import os
import stat
import time
import urllib.error
import urllib.request
from pathlib import Path

import numpy as np
import torch

from code.unified_selector.registry import GLOBAL_SOLVERS
from .solver_code_corpus import ROOT, MODEL, digest, check_sensitive, source_path, write_json
from .solver_code_encoder import CODE_DIM, ROLES, check_vectors


SETTINGS = dict(model=MODEL, output_dimension=CODE_DIM, output_dtype='float', input_type=None, truncation=False)
ENDPOINT = 'https://api.voyageai.com/v1/embeddings'


def validate_bundle(bundle):
    if not isinstance(bundle, dict) or bundle.get('kind') != 'production' or bundle.get('provider') != 'voyage':
        raise ValueError('Only real production Voyage bundles are accepted; no mock/random fallback')
    if bundle.get('settings') != SETTINGS or bundle.get('roles') != list(ROLES) or bundle.get('solver_names') != GLOBAL_SOLVERS:
        raise ValueError('Embedding model/settings/role order/solver identity mismatch')
    if bundle.get('corpus_ready') is not True or not bundle.get('calls'):
        raise ValueError('Production vectors require reviewed source bindings and request provenance')
    if any(call.get('source') != 'voyage-http' or not call.get('timestamp_utc') for call in bundle['calls']):
        raise ValueError('Mock/missing API request provenance is not a production embedding')
    for key in ('corpus_sha256', 'cache_sha256'):
        if len(bundle.get(key, '')) != 64:
            raise ValueError('Missing locked corpus/cache provenance')
    check_vectors(bundle['vectors'], bundle['role_mask'])


def load_bundle(path):
    path = Path(path)
    lock = json.loads(path.with_suffix('.lock.json').read_text())
    if lock.get('sha256') != digest(path.read_bytes()):
        raise ValueError('Embedding bundle changed after it was locked')
    bundle = torch.load(path, map_location='cpu', weights_only=False)
    validate_bundle(bundle)
    return bundle


def api_key(path=None):
    if path is None:
        key = os.environ.get('VOYAGE_API_KEY', '').strip()
    else:
        path = Path(path).expanduser().resolve()
        project = Path(__file__).resolve().parents[2]
        metadata = path.stat()
        if path.is_relative_to(project) or metadata.st_uid != os.getuid() or stat.S_IMODE(metadata.st_mode) & 0o077:
            raise ValueError('Key file must be private (mode600), owned by you, and outside this Git repository')
        key = path.read_text().strip()
    if not key or '\n' in key:
        raise ValueError('Set VOYAGE_API_KEY or supply a private --api-key-file; no request was sent')
    return key


def request_embeddings(texts, key):
    for text in texts:
        check_sensitive(text)
    request = urllib.request.Request(ENDPOINT, data=json.dumps(dict(SETTINGS, input=texts)).encode(),
                                     headers={'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key})
    for attempt in range(5):
        try:
            with urllib.request.urlopen(request, timeout=120) as response:
                result = json.load(response)
                request_id = response.headers.get('x-request-id')
            break
        except urllib.error.HTTPError as error:
            if error.code not in (429, 500, 502, 503, 504) or attempt == 4:
                # Do not echo remote response bodies, request headers, or credentials.
                raise RuntimeError(f'Voyage HTTP {error.code}; no backend substitution was attempted') from None
            time.sleep(min(60, 2 ** (attempt + 1)))
        except urllib.error.URLError:
            raise RuntimeError('Voyage network request failed; cached completed chunks are retained') from None
    if result.get('model', MODEL) != MODEL:
        raise ValueError('Server returned a different embedding model')
    items = sorted(result['data'], key=lambda row: row['index'])
    if [row['index'] for row in items] != list(range(len(texts))):
        raise ValueError('API response indices do not match the request')
    vectors = np.asarray([row['embedding'] for row in items], dtype=np.float32)
    if vectors.shape != (len(texts), CODE_DIM) or not np.isfinite(vectors).all() or (np.linalg.norm(vectors, axis=-1) == 0).any():
        raise ValueError('Invalid Voyage vectors; not cached')
    metadata = dict(source='voyage-http', timestamp_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    request_id=request_id, model=result.get('model', MODEL), usage=result.get('usage', {}),
                    revision=result.get('revision'), revision_note='Provider may not expose a pinned model revision')
    return vectors, metadata


def cache_key(chunk, corpus):
    return digest(dict(chunk_id=chunk['id'], text_sha256=chunk['text_sha256'], settings=SETTINGS,
                       preprocessing=corpus['preprocessing'], tokenizer=corpus['tokenizer_sha256'],
                       max_tokens=corpus['max_tokens'], manifest=corpus['manifest_sha256']))


def validate_corpus(corpus, snapshot=None):
    expected = digest({k: v for k, v in corpus.items() if k != 'sha256'})
    if corpus.get('sha256') != expected or corpus.get('model') != MODEL or corpus.get('max_tokens') != 4096:
        raise ValueError('Corpus hash/model/chunking mismatch; rebuild the corpus')
    if corpus.get('roles') != list(ROLES) or [s['solver_name'] for s in corpus['solvers']] != GLOBAL_SOLVERS:
        raise ValueError('Corpus solver/role order mismatch')
    ids = [c['id'] for c in corpus['chunks']]
    if len(ids) != len(set(ids)):
        raise ValueError('Duplicate chunk identifiers')
    for chunk in corpus['chunks']:
        check_sensitive(chunk['text'])
        if chunk['text_sha256'] != digest(chunk['text'].encode()) or not 0 < chunk['tokens'] <= 4096:
            raise ValueError('Chunk content/token count changed')
    if snapshot is not None:
        if digest(snapshot) != corpus['manifest_sha256']:
            raise ValueError('Source manifest changed; rebuild the corpus')
        for name, sha in corpus['source_hashes'].items():
            if digest(source_path(snapshot, name).read_bytes()) != sha:
                raise ValueError(f'Allowlisted source changed: {name}; rebuild the corpus')


def read_cache(path, expected_key):
    value = json.loads(path.read_text())
    if value.get('key') != expected_key or value.get('settings') != SETTINGS or value.get('provider') != 'voyage':
        raise ValueError('Cache provenance/settings mismatch')
    vector = np.asarray(value['embedding'], dtype=np.float32)
    if vector.shape != (CODE_DIM,) or not np.isfinite(vector).all() or np.linalg.norm(vector) == 0:
        raise ValueError('Invalid cached embedding')
    if (value.get('embedding_sha256') != digest(vector.tobytes()) or not value.get('call', {}).get('timestamp_utc')
            or value.get('call', {}).get('source') != 'voyage-http'):
        raise ValueError('Cached vector changed or has no request provenance')
    return vector, value['call']


def l2mean(values):
    values = np.asarray(values, dtype=np.float64)
    values /= np.linalg.norm(values, axis=-1, keepdims=True)
    result = values.mean(axis=0)
    length = np.linalg.norm(result)
    if not np.isfinite(length) or length < 1e-12:
        raise ValueError('Degenerate mean code vector')
    return (result / length).astype(np.float32)


def assemble(corpus, cache_dir, output):
    validate_corpus(corpus)
    if not corpus['ready']:
        raise ValueError('Unresolved actual solver bindings cannot become production embeddings')
    entries, calls, cache_hashes = {}, {}, {}
    for chunk in corpus['chunks']:
        key = cache_key(chunk, corpus)
        path = cache_dir / (key + '.json')
        entries[chunk['id']], call = read_cache(path, key)
        calls[digest(call)] = call
        cache_hashes[key] = digest(path.read_bytes())
    vectors = np.zeros((len(GLOBAL_SOLVERS), len(ROLES), CODE_DIM), dtype=np.float32)
    mask = np.zeros(vectors.shape[:2], dtype=bool)
    for row, solver in enumerate(corpus['solvers']):
        for column, role in enumerate(ROLES):
            variants = []
            for variant in solver['variants']:
                ids = variant['roles'][role]
                if ids:
                    variants.append(l2mean([entries[key] for key in ids]))
            if variants:
                vectors[row, column] = l2mean(variants)
                mask[row, column] = True
    bundle = dict(schema='r45-embeddings-v1', kind='production', provider='voyage', settings=SETTINGS,
                  solver_names=GLOBAL_SOLVERS, roles=list(ROLES), vectors=torch.from_numpy(vectors),
                  role_mask=torch.from_numpy(mask), corpus_sha256=corpus['sha256'], corpus_ready=True,
                  cache_sha256=digest(cache_hashes), calls=list(calls.values()),
                  aggregation='L2 chunks -> equal chunk mean/L2 per variant -> equal distinct variant mean/L2')
    validate_bundle(bundle)
    output = Path(output)
    if output.exists() or output.with_suffix('.lock.json').exists():
        raise ValueError('Refusing to overwrite a locked embedding bundle; choose a new output path')
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix('.tmp')
    torch.save(bundle, temporary)
    temporary.replace(output)
    write_json(output.with_suffix('.lock.json'), dict(sha256=digest(output.read_bytes()),
               corpus_sha256=corpus['sha256'], settings=SETTINGS, cache_sha256=bundle['cache_sha256']))
    return bundle


def generate(corpus, cache_dir, allow_upload=False, max_tokens=None, key_file=None, batch_size=16):
    validate_corpus(corpus)
    pending = []
    for chunk in corpus['chunks']:
        key = cache_key(chunk, corpus)
        path = cache_dir / (key + '.json')
        if path.exists():
            read_cache(path, key)
        else:
            pending.append((chunk, key, path))
    plan = dict(total_chunks=len(corpus['chunks']), uncached_chunks=len(pending),
                uncached_tokens=sum(c['tokens'] for c, _, _ in pending), settings=SETTINGS, ready=corpus['ready'])
    if not allow_upload:
        return plan
    if not corpus['ready']:
        raise ValueError('Draft corpus has unresolved source/config bindings; upload refused')
    if max_tokens is None or plan['uncached_tokens'] > max_tokens:
        raise ValueError('Explicit --max-tokens budget is required and must cover the uncached input')
    if not 1 <= batch_size <= 16:
        raise ValueError('Request batch must be 1..16 chunks (at most 65536 input tokens)')
    if not pending:
        return plan
    key = api_key(key_file)
    cache_dir.mkdir(parents=True, exist_ok=True)
    for offset in range(0, len(pending), batch_size):
        items = pending[offset:offset + batch_size]
        vectors, call = request_embeddings([c['text'] for c, _, _ in items], key)
        for (chunk, identity, path), vector in zip(items, vectors):
            write_json(path, dict(key=identity, provider='voyage', settings=SETTINGS, call=call,
                                 text_sha256=chunk['text_sha256'], embedding=vector.tolist(),
                                 embedding_sha256=digest(vector.tobytes())))
        print(f"[embedding] {min(offset + batch_size, len(pending))}/{len(pending)} uncached chunks", flush=True)
    return plan


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', choices=('plan', 'embed', 'assemble'), default='plan')
    parser.add_argument('--corpus', type=Path, default=ROOT / 'corpus/corpus.json')
    parser.add_argument('--cache-dir', type=Path, default=ROOT / 'embedding_cache')
    parser.add_argument('--output', type=Path, default=ROOT / 'solver_code_vectors.pt')
    parser.add_argument('--allow-upload', action='store_true')
    parser.add_argument('--max-tokens', type=int)
    parser.add_argument('--api-key-file', type=Path)
    args = parser.parse_args()
    corpus = json.loads(args.corpus.read_text())
    validate_corpus(corpus, json.loads(args.corpus.with_name('source_snapshot.json').read_text()))
    if args.stage == 'embed' and not args.allow_upload:
        parser.error('--stage embed requires --allow-upload (source code is sent to Voyage)')
    if args.stage in ('plan', 'embed'):
        print(json.dumps(generate(corpus, args.cache_dir, args.stage == 'embed', args.max_tokens, args.api_key_file), indent=2))
    else:
        bundle = assemble(corpus, args.cache_dir, args.output)
        print(f"Locked offline vectors: {args.output}, shape={tuple(bundle['vectors'].shape)}")


if __name__ == '__main__':
    main()
